from src.langgraph_agentic_ai.main import load_app

if __name__ == "__main__":
    print("---- Initializing the application ----")
    load_app()

