# server.py
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import logging

from src.langgraph_agentic_ai.main import load_app
from src.langgraph_agentic_ai.logging.config import configure_logging
from src.langgraph_agentic_ai.logging.context import set_correlation_id, get_correlation_id
from src.langgraph_agentic_ai.logging.exceptions import AppError

# configure logging once at process start
configure_logging()
logger = logging.getLogger("api")

app = FastAPI(title="ServiceNow Webhook -> LangGraph State Builder")

# Per-request correlation id (use incoming header if present)
@app.middleware("http")
async def correlation_middleware(request: Request, call_next):
    incoming = request.headers.get("X-Correlation-Id")
    set_correlation_id(incoming)  # generate new if None
    response = await call_next(request)
    response.headers["X-Correlation-Id"] = get_correlation_id()
    return response

# Typed application errors -> clean JSON with correlation id
@app.exception_handler(AppError)
async def app_error_handler(request: Request, exc: AppError):
    logger.warning(
        "app_error",
        extra={
            "code": exc.code,
            "status": exc.status,
            "path": str(request.url.path),
            "method": request.method,
        },
    )
    return JSONResponse(
        status_code=exc.status,
        content={
            "error": {"code": exc.code, "message": str(exc)},
            "correlation_id": get_correlation_id(),
        },
    )

# Fallback for unhandled exceptions
@app.exception_handler(Exception)
async def unhandled_handler(request: Request, exc: Exception):
    logger.exception(
        "unhandled_exception",
        extra={"path": str(request.url.path), "method": request.method},
    )
    return JSONResponse(
        status_code=500,
        content={
            "error": {"code": "internal_error", "message": "Unexpected error"},
            "correlation_id": get_correlation_id(),
        },
    )

@app.post("/webhook/db_backup_failure/servicenow")
async def webhook_servicenow(request: Request):
    payload = await request.json()
    # Log a safe summary (do not dump entire payload in INFO).
    logger.info(
        "webhook_received",
        extra={
            "route": "/webhook/db_backup_failure/servicenow",
            "payload_keys": list(payload.keys())[:20],
        },
    )
    # load_app may raise AppError; our handlers above will serialize it
    state = load_app(payload)
    return JSONResponse(state)