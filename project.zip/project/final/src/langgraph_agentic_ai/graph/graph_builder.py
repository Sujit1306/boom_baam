from langgraph.graph import StateGraph, START, END
from ..state.state import AgentState
from ..nodes.state_builder_node_new import StateBuilderNode
from ..nodes.error_categorizer_node import ErrorCategorizerNode
from ..nodes.query_vdb_node import QueryVDBNode
from ..nodes.print_state_node import PrintStateNode


class GraphBuilder:
    def __init__(self):
        self.graph_builder = StateGraph(AgentState)

    def setup_graph(self):
        print("---- Adding Nodes and Edges ----")
        state_builder_node = StateBuilderNode()
        error_categorizer_node = ErrorCategorizerNode()
        query_vdb_node = QueryVDBNode()
        print_state_node = PrintStateNode()
        
        # add nodes
        self.graph_builder.add_node("state_builder", state_builder_node.build_state_from_payload)
        self.graph_builder.add_node("error_categorizer", error_categorizer_node.categorize_error)
        self.graph_builder.add_node("query_vdb", query_vdb_node.find_sop_id)
        self.graph_builder.add_node("print_state", print_state_node.print_state)
        
        # add edges
        self.graph_builder.add_edge(START, "state_builder")
        self.graph_builder.add_edge("state_builder", "error_categorizer")
        self.graph_builder.add_edge("error_categorizer", "query_vdb")
        self.graph_builder.add_edge ("query_vdb", "print_state")
        self.graph_builder.add_edge("print_state", END)

        print("---- Graph Built Successfully ----")

        return self.graph_builder.compile()