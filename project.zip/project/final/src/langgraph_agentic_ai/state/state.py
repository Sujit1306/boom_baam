from __future__ import annotations
from typing import Any, Dict, List, Optional
from typing_extensions import TypedDict


class Attachment(TypedDict, total=False):
    name: str
    source: str


class AgentState(TypedDict, total=False):
    payload: Dict[str, Any]
    ticket_id: str
    raw_ticket: Dict[str, Any]
    attachments: List[Attachment]
    service_now: Dict[str, Any]
    service_now_updates: Dict[str, Any]
    db_type: Optional[str]
    error_category: Optional[str]
    environment: Dict[str, Any]
    inputs: Dict[str, Any]
    execution_plan: Dict[str, Any]
    remediation: Dict[str, Any]
    notification: Dict[str, Any]
    audit: Dict[str, Any]
    error: Dict[str, Any]