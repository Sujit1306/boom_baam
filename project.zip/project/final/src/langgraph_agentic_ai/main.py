# src/langgraph_agentic_ai/main.py
import logging
from .graph.graph_builder import GraphBuilder

from .logging.exceptions import AppError, GraphExecutionError, ValidationError
from .logging.decorators import traced  # optional but recommended

logger = logging.getLogger(__name__)

# If you want load_app to be traced automatically:
@traced("load_app", to_error=GraphExecutionError)
def load_app(payload: dict):
    # 1) Validate input early for predictable errors
    if not isinstance(payload, dict):
        raise ValidationError("Payload must be a JSON object (dict)")

    logger.info(
        "setting_up_graph",
        extra={"payload_keys": list(payload.keys())[:20]},  # safe summary only
    )

    # 2) Build graph
    graphbuilder = GraphBuilder()
    graph = graphbuilder.setup_graph()

    logger.info("invoking_graph")

    # 3) Invoke graph (if graph.invoke can raise, it will be wrapped by @traced)
    state = graph.invoke({"payload": payload})

    logger.info(
        "graph_invocation_completed",
        extra={
            # include safe observability fields if available from state
            # e.g., "final_node": state.get("last_node"), "steps": state.get("steps")
        },
    )
    return state