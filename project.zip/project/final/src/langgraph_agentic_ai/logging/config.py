import json, logging, logging.config, os
from logging.handlers import RotatingFileHandler
from .context import ContextFilter

def get_log_level():
    return os.getenv("LOG_LEVEL", "INFO").upper()

def get_log_dir():
    return os.getenv("LOG_DIR", "logs")

def ensure_log_dir():
    os.makedirs(get_log_dir(), exist_ok=True)

def dict_config():
    ensure_log_dir()
    return {
        "version": 1,
        "disable_existing_loggers": False,
        "filters": {
            "ctx": {"()": ContextFilter},  # add correlation_id, request_id, etc.
        },
        "formatters": {
            "console": {
                "format": "%(asctime)s | %(levelname)s | %(name)s | %(correlation_id)s | %(message)s"
            },
            "json": {
                "()": "logging.Formatter",
                "format": json.dumps({
                    "ts": "%(asctime)s",
                    "level": "%(levelname)s",
                    "logger": "%(name)s",
                    "module": "%(module)s",
                    "func": "%(funcName)s",
                    "line": "%(lineno)d",
                    "cid": "%(correlation_id)s",
                    "msg": "%(message)s"
                })
            }
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "level": get_log_level(),
                "formatter": "console",
                "filters": ["ctx"],
                "stream": "ext://sys.stdout",
            },
            "file": {
                "class": "logging.handlers.RotatingFileHandler",
                "level": get_log_level(),
                "formatter": "json",
                "filters": ["ctx"],
                "filename": os.path.join(get_log_dir(), "app.log"),
                "maxBytes": 10 * 1024 * 1024,
                "backupCount": 5,
                "encoding": "utf-8",
            },
        },
        "root": {
            "level": get_log_level(),
            "handlers": ["console", "file"],
        },
    }

def configure_logging():
    logging.config.dictConfig(dict_config())