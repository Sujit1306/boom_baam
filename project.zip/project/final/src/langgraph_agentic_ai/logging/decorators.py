# src/langgraph_agentic_ai/logging/decorators.py
import functools, logging, time
from typing import Callable, Type
from .exceptions import AppError, GraphExecutionError

logger = logging.getLogger(__name__)

def traced(operation: str, to_error: Type[AppError] = GraphExecutionError):
    def outer(fn: Callable):
        @functools.wraps(fn)
        def inner(*args, **kwargs):
            start = time.time()
            logger.debug("start", extra={"op": operation})
            try:
                result = fn(*args, **kwargs)
                elapsed = round((time.time() - start) * 1000)
                logger.info("ok", extra={"op": operation, "ms": elapsed})
                return result
            except AppError:
                # already typed; just log and re-raise
                logger.exception("app_error", extra={"op": operation})
                raise
            except Exception as e:
                logger.exception("unhandled", extra={"op": operation})
                raise to_error(str(e)) from e
        return inner
    return outer