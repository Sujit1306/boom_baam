# exception heirarchy
class AppError(Exception):
    """Base for all expected application errors."""
    code = "app_error"
    status = 500

class ValidationError(AppError):
    code = "validation_error"
    status = 400

class ExternalServiceError(AppError):
    code = "external_service_error"
    status = 502

class LLMError(AppError):
    code = "llm_error"
    status = 502

class GraphExecutionError(AppError):
    code = "graph_execution_error"
    status = 500