# correlation id/contextvars utilities
import logging, uuid, contextvars

correlation_id_var = contextvars.ContextVar("correlation_id", default="-")

class ContextFilter(logging.Filter):
    def filter(self, record):
        record.correlation_id = correlation_id_var.get()
        return True

def set_correlation_id(value: str | None = None):
    correlation_id_var.set(value or str(uuid.uuid4()))

def get_correlation_id():
    return correlation_id_var.get()