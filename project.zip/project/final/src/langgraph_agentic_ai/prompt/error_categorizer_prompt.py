from __future__ import annotations
from ..state.state import AgentState
from pydantic import BaseModel

class DBType_Error(BaseModel):
    db_type: str
    error_category: str 

class ErrorCategorizerPrompt:

    @staticmethod
    def generate_prompt(state: AgentState) -> str:
        description = state['raw_ticket']["description"]
        assignment_group = state['raw_ticket']["assignment_group"]
        # prompt = (
        #     "You are a database incident classification engine.\n"
        #     "Your task is to classify the ticket into EXACTLY ONE of the predefined error categories below.\n\n"

        #     "Rules:\n"
        #     "- Choose ONE and ONLY ONE category\n"
        #     "- Output must EXACTLY match one of the categories (case-sensitive)\n"
        #     "- Do NOT rephrase, summarize, or explain\n"
        #     "- If multiple apply, choose the MOST SPECIFIC one\n"
        #     "- Base your decision on BOTH the ticket description and assignment group\n"
        #     "- Do NOT return JSON, markdown, or extra text\n\n"

        #     "Allowed Categories:\n"
        #     "SQL:\n"
        #     "- SQL Failed to connect to instance\n"
        #     "- SQL Failed backup of the transaction log - transaction log chain broken\n\n"

        #     "Oracle:\n"
        #     "- Oracle ORA-08181\n"
        #     "- Oracle DB in NOARCHIVELOG mode\n"
        #     "- Oracle DB is not open\n"
        #     "- Oracle DB is not part of DG setup\n"
        #     "- Oracle Invalid username and password\n"
        #     "- Oracle No archive logs to backup\n"
        #     "- Oracle No space left on filesystem\n"
        #     "- Oracle RMAN Script did not finish\n\n"

        #     "Ticket Description:\n"
        #     f"{description}\n\n"

        #     "Assignment Group:\n"
        #     f"{assignment_group}\n\n"

        #     "Output (return ONLY the category string):"
        # )
        prompt = f"""Error Description: {description}
        Assignment Group: {assignment_group}
        Return JSON:
        {{
            "db_type": "SQL | Oracle | Unknown",
            "error_category": "...one"
        }}"""
        return prompt