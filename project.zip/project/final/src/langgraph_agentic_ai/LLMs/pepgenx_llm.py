from __future__ import annotations
import base64
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional
import requests
try:
    from dotenv import load_dotenv, find_dotenv
    load_dotenv(find_dotenv(), override=False)
except Exception:
    pass

def _require_env(name: str) -> str:
    val = os.getenv(name)
    if not val:
        raise RuntimeError(f"Missing required env var: {name}")
    return val


# ------------------------------
# Okta token provider (client_credentials)
# ------------------------------
@dataclass
class OktaConfig:
    token_url: str
    client_id: str
    client_secret: str
    scope: str = ""
    use_basic_auth: bool = True
    refresh_skew_s: int = 30
    timeout_s: float = 30.0


class OktaTokenProvider:
    def __init__(self, cfg: OktaConfig):
        self.cfg = cfg
        self._token: Optional[str] = None
        self._expires_at: float = 0.0
        self._session = requests.Session()

    def get_token(self) -> str:
        now = time.time()
        if self._token and now < (self._expires_at - self.cfg.refresh_skew_s):
            return self._token
        return self.force_refresh()

    def force_refresh(self) -> str:
        data = {"grant_type": "client_credentials"}
        if self.cfg.scope:
            data["scope"] = self.cfg.scope

        headers: Dict[str, str] = {"Content-Type": "application/x-www-form-urlencoded"}
        if self.cfg.use_basic_auth:
            basic = base64.b64encode(
                f"{self.cfg.client_id}:{self.cfg.client_secret}".encode("utf-8")
            ).decode("utf-8")
            headers["Authorization"] = f"Basic {basic}"
        else:
            data["client_id"] = self.cfg.client_id
            data["client_secret"] = self.cfg.client_secret

        resp = self._session.post(self.cfg.token_url, data=data, headers=headers, timeout=self.cfg.timeout_s)
        resp.raise_for_status()
        payload = resp.json()

        token = payload.get("access_token")
        expires_in = payload.get("expires_in", 3600)
        if not token:
            raise RuntimeError(f"Okta did not return access_token. Response: {payload}")

        self._token = token
        self._expires_at = time.time() + float(expires_in)
        return token


# ------------------------------
# PepGenX client
# ------------------------------
@dataclass
class PepGenXConfig:
    endpoint: str
    generation_model: str = "gpt-4o-mini"
    generation_model_version: int = 0
    max_tokens: int = 500
    temperature: float = 0.0
    n: int = 1
    verify_tls: bool = True
    timeout_s: float = 60.0
    max_retries: int = 2
    retry_backoff_s: float = 0.8
    team_id: str = ""
    project_id: str = ""
    x_pepgenx_apikey: str = ""


class PepGenXClient:
    def __init__(self, cfg: PepGenXConfig, token_provider: OktaTokenProvider):
        self.cfg = cfg
        self.token_provider = token_provider
        self._session = requests.Session()

    def generate(self, prompt: str) -> str:
        payload = {
            "prompt": prompt,
            "generation_model": self.cfg.generation_model,
            "generation_model_version": self.cfg.generation_model_version,
            "max_tokens": self.cfg.max_tokens,
            "temperature": self.cfg.temperature,
            "n": self.cfg.n,
            "pii_category_filter": {},
        }

        last_exc: Optional[Exception] = None
        for attempt in range(self.cfg.max_retries + 1):
            try:
                token = self.token_provider.get_token()
                headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
                if self.cfg.team_id:
                    headers["team_id"] = self.cfg.team_id
                if self.cfg.project_id:
                    headers["project_id"] = self.cfg.project_id
                if self.cfg.x_pepgenx_apikey:
                    headers["x-pepgenx-apikey"] = self.cfg.x_pepgenx_apikey

                resp = self._session.post(
                    self.cfg.endpoint,
                    json=payload,
                    headers=headers,
                    timeout=self.cfg.timeout_s,
                    verify=self.cfg.verify_tls,
                )

                if resp.status_code in (401, 403):
                    self.token_provider.force_refresh()
                    token2 = self.token_provider.get_token()
                    headers["Authorization"] = f"Bearer {token2}"
                    resp = self._session.post(
                        self.cfg.endpoint,
                        json=payload,
                        headers=headers,
                        timeout=self.cfg.timeout_s,
                        verify=self.cfg.verify_tls,
                    )

                resp.raise_for_status()
                return self._extract_text(resp.json())
            except Exception as e:
                last_exc = e
                if attempt < self.cfg.max_retries:
                    time.sleep(self.cfg.retry_backoff_s * (2 ** attempt))
                    continue
                raise
        raise last_exc or RuntimeError("PepGenX request failed")

    @staticmethod
    def _extract_text(data: Any) -> str:
        if isinstance(data, dict):
            resp = data.get("response")
            if isinstance(resp, str) and resp.strip():
                return resp.strip()
            if isinstance(resp, list) and resp and isinstance(resp[0], str):
                return resp[0].strip()
            for k in ("output", "text", "result"):
                v = data.get(k)
                if isinstance(v, str) and v.strip():
                    return v.strip()
            return str(data)
        return str(data)


def get_pepgenx_llm_client() -> PepGenXClient:
    """Singleton PepGenX client built from env vars."""

    okta_cfg = OktaConfig(
        token_url=_require_env("OKTA_TOKEN_URL"),
        client_id=_require_env("OKTA_CLIENT_ID"),
        client_secret=_require_env("OKTA_CLIENT_SECRET"),
        scope=os.getenv("OKTA_SCOPE", ""),
        use_basic_auth=True,
    )
    provider = OktaTokenProvider(okta_cfg)

    pep_cfg = PepGenXConfig(
        endpoint=_require_env("PEPGENX_LLM_URL"),
        generation_model=os.getenv("PEPGENX_MODEL", "gpt-4o-mini"),
        generation_model_version=int(os.getenv("PEPGENX_MODEL_VERSION", "0")),
        max_tokens=int(os.getenv("PEPGENX_MAX_TOKENS", "500")),
        temperature=float(os.getenv("PEPGENX_TEMPERATURE", "0")),
        n=int(os.getenv("PEPGENX_N", "1")),
        verify_tls=os.getenv("PEPGENX_VERIFY_TLS", "true").lower() == "true",
        team_id=os.getenv("TEAM_ID", ""),
        project_id=os.getenv("PROJECT_ID", ""),
        x_pepgenx_apikey=os.getenv("X_PEPGENX_APIKEY", ""),
    )

    return PepGenXClient(pep_cfg, provider)
     
