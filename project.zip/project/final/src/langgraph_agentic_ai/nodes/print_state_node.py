from __future__ import annotations
from ..state.state import AgentState

class PrintStateNode:

    def print_state(self, state: AgentState):
        # print("---- PrintStateNode: Current State: ----\n", state)
        return state