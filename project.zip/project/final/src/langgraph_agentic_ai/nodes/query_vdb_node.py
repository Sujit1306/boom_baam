from __future__ import annotations
from ..state.state import AgentState 
import base64
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import requests
try:
    from dotenv import load_dotenv, find_dotenv
    load_dotenv(find_dotenv(), override=False)
except Exception:
    pass

class QueryVDBNode:
    """
    Populates the SOP ID in the state by querying the vector database with the input query.
    """
    def __init__(self):
        self.state = {}
    
    def find_sop_id(self, state: AgentState):
        def _require_env(name: str) -> str:
            val = os.getenv(name)
            if not val:
                raise RuntimeError(f"Missing required env var: {name}")
            return val
        # -----------------------------
        # Okta client-credentials
        # -----------------------------
        @dataclass
        class OktaConfig:
            token_url: str
            client_id: str
            client_secret: str
            scope: str = ""
            use_basic_auth: bool = True
            refresh_skew_s: int = 30
            timeout_s: float = 30.0


        class OktaTokenProvider:
            def __init__(self, cfg: OktaConfig):
                self.cfg = cfg
                self._token: Optional[str] = None
                self._expires_at: float = 0.0
                self._session = requests.Session()

            def get_token(self) -> str:
                now = time.time()
                if self._token and now < (self._expires_at - self.cfg.refresh_skew_s):
                    return self._token
                return self.force_refresh()

            def force_refresh(self) -> str:
                data = {"grant_type": "client_credentials"}
                if self.cfg.scope:
                    data["scope"] = self.cfg.scope

                headers = {"Content-Type": "application/x-www-form-urlencoded"}
                if self.cfg.use_basic_auth:
                    basic = base64.b64encode(
                        f"{self.cfg.client_id}:{self.cfg.client_secret}".encode("utf-8")
                    ).decode("utf-8")
                    headers["Authorization"] = f"Basic {basic}"
                else:
                    data["client_id"] = self.cfg.client_id
                    data["client_secret"] = self.cfg.client_secret

                resp = self._session.post(
                    self.cfg.token_url,
                    data=data,
                    headers=headers,
                    timeout=self.cfg.timeout_s,
                )
                try:
                    resp.raise_for_status()
                except requests.HTTPError:
                    print(f"[TOKEN ERROR] HTTP {resp.status_code} body: {resp.text[:1000]}", flush=True)
                    raise
                
                try:
                    payload = resp.json()
                except Exception:
                    print(f"[TOKEN ERROR] Non-JSON response from Okta. Status={resp.status_code}, "
                          f"Body starts with: {resp.text[:1000]!r}", flush=True)
                    raise
                
                token = payload.get("access_token")
                if not token:
                    raise RuntimeError(f"Okta did not return access_token. Response: {payload}")
                expires_in = float(payload.get("expires_in", 3600))
                self._token = token
                self._expires_at = time.time() + expires_in
                return token


        # -----------------------------
        # PepGenXEmbed client
        # -----------------------------
        @dataclass
        class PepGenXEmbedConfig:
            verify_tls: bool = True
            timeout_s: float = 60.0
            max_retries: int = 2
            retry_backoff_s: float = 0.8
            team_id: str = ""
            project_id: str = ""
            x_pepgenx_apikey: str = ""
            token_encoding: str = ""
            embedding_model_name: str = ""


        class PepGenXEmbedClient:
            def __init__(self, cfg: PepGenXEmbedConfig, token_provider: OktaTokenProvider):
                self.cfg = cfg
                self.token_provider = token_provider
                self._session = requests.Session()

            def embed_query(
                self,
                *,
                url: str,
                query: str,
                truncate: str,
            ) -> Dict[str, Any]:
                payload = {
                    "query": query, 
                    "truncate": truncate
                }
                return self._post_json(url, payload)


            # Shared POST with retries
            def _post_json(self, url: str, payload: Dict[str, Any]) -> Dict[str, Any]:
                token = self.token_provider.get_token()
                headers = {
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {token}",
                    "team_id": self.cfg.team_id,
                    "project_id": self.cfg.project_id,
                    "x-pepgenx-apikey": self.cfg.x_pepgenx_apikey,
                    # Embedding headers 
                    "token_encoding": self.cfg.token_encoding,
                    "embedding_model_name": self.cfg.embedding_model_name,
                }
                resp = self._session.post(
                    url,
                    json=payload,
                    headers=headers,
                    timeout=self.cfg.timeout_s,
                    verify=self.cfg.verify_tls,
                )
                return resp.json()

        # -----------------------------
        # PepGenXQuery client
        # -----------------------------
        @dataclass
        class PepGenXQueryConfig:
            verify_tls: bool = True
            timeout_s: float = 60.0
            max_retries: int = 2
            retry_backoff_s: float = 0.8
            team_id: str = ""
            project_id: str = ""
            x_pepgenx_apikey: str = ""


        class PepGenXQueryClient:
            def __init__(self, cfg: PepGenXQueryConfig, token_provider: OktaTokenProvider):
                self.cfg = cfg
                self.token_provider = token_provider
                self._session = requests.Session()

            def vector_search(
                self,
                *,
                url: str,
                input_string_vector: List[float],
                number_of_result_limit: int = 5,
                metadata_filter: List[str],
                additional_fields: List[str],
            ) -> Dict[str, Any]:
                payload = {
                    "input_string_vector": input_string_vector,
                    "number_of_result_limit": number_of_result_limit,
                    "metadata_filter": metadata_filter,
                    "additional_fields": additional_fields,
                }
                return self._post_json(url, payload)

            # Shared POST with retries
            def _post_json(self, url: str, payload:Dict[str, Any] ) -> Dict[str, Any]:
                token = self.token_provider.get_token()
                headers = {
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {token}",
                    "team_id": self.cfg.team_id,
                    "project_id": self.cfg.project_id,
                    "x-pepgenx-apikey": self.cfg.x_pepgenx_apikey,
                }
                resp = self._session.post(
                    url,
                    json=payload,
                    headers=headers,
                    timeout=self.cfg.timeout_s,
                    verify=self.cfg.verify_tls,
                )
                return resp.json()


        def get_query_client_from_env() -> PepGenXQueryClient:
            okta_cfg = OktaConfig(
                token_url=_require_env("OKTA_TOKEN_URL"),
                client_id=_require_env("OKTA_CLIENT_ID"),
                client_secret=_require_env("OKTA_CLIENT_SECRET"),
                scope=os.getenv("OKTA_SCOPE", ""),
                use_basic_auth=True,
            )
            provider = OktaTokenProvider(okta_cfg)
            cfg = PepGenXQueryConfig(
                verify_tls=os.getenv("PEPGENX_VERIFY_TLS").lower() == "true",
                timeout_s=float(os.getenv("PEPGENX_TIMEOUT_S")),
                max_retries=int(os.getenv("PEPGENX_MAX_RETRIES")),
                retry_backoff_s=float(os.getenv("PEPGENX_RETRY_BACKOFF_S")),
                team_id=_require_env("TEAM_ID"),
                project_id=_require_env("PROJECT_ID"),
                x_pepgenx_apikey=_require_env("X_PEPGENX_APIKEY"),
            )
            return PepGenXQueryClient(cfg, provider)


        def get_embed_client_from_env() -> PepGenXEmbedClient:
            okta_cfg = OktaConfig(
                token_url=_require_env("OKTA_TOKEN_URL"),
                client_id=_require_env("OKTA_CLIENT_ID"),
                client_secret=_require_env("OKTA_CLIENT_SECRET"),
                scope=os.getenv("OKTA_SCOPE", ""),
                use_basic_auth=True,
            )
            provider = OktaTokenProvider(okta_cfg)

            cfg = PepGenXEmbedConfig(
                verify_tls=os.getenv("PEPGENX_VERIFY_TLS").lower() == "true",
                timeout_s=float(os.getenv("PEPGENX_TIMEOUT_S")),
                max_retries=int(os.getenv("PEPGENX_MAX_RETRIES")),
                retry_backoff_s=float(os.getenv("PEPGENX_RETRY_BACKOFF_S")),
                team_id=_require_env("TEAM_ID"),
                project_id=_require_env("PROJECT_ID"),
                x_pepgenx_apikey=_require_env("X_PEPGENX_APIKEY"),
                token_encoding=os.getenv("TOKEN_ENCODING"),
                embedding_model_name=os.getenv("EMBEDDING_MODEL_NAME"),
            )
            return PepGenXEmbedClient(cfg, provider)
        
        embed_client = get_embed_client_from_env()
        embed_url = os.getenv("PEPGENX_EMBED_URL")
        query_url = os.getenv("PEPGENX_QUERY_URL")

        print("---- [QueryVDBNode]: Querying VDB for SOP ID ----")

        query = f"""{state["error_category"]}""" #add db_type in this query
        truncate = "NONE"
        embed_data = embed_client.embed_query(url=embed_url, query=query, truncate=truncate)
        embeddings = embed_data.get("embeddings", []) 
        query_client = get_query_client_from_env()
        query_data = query_client.vector_search(
            url=query_url,
            input_string_vector=embeddings,  
            number_of_result_limit=1,
            metadata_filter="",
            additional_fields=["title","file_name"]
        )
        sop_id = query_data['details'][0]['title']
        print("---- [QueryVDBNode]: ", sop_id, "----")

        return {"execution_plan": {"sop_id": sop_id, "steps": [], "auto_fix_supported": False}}