from __future__ import annotations
from ..state.state import AgentState

class StateBuilderNode:

    def build_state_from_payload(self, state: AgentState):
        print("---- [StateBuilderNode]: Building State from Payload ----")
        state["payload"] =          state["payload"]
        state["ticket_id"] =        state["payload"].get("ticket", {}).get("number", "")
        state["raw_ticket"] = {
            "number":               state["payload"].get("ticket", {}).get("number", ""),
            "state":                state["payload"].get("ticket", {}).get("state", ""),
            "short_description":    state["payload"].get("ticket", {}).get("short_description", ""),
            "description":          state["payload"].get("ticket", {}).get("description", ""),
            "assignment_group":     state["payload"].get("ticket", {}).get("assignment_group", ""),
            "service_offering":     state["payload"].get("ticket", {}).get("service_offering", ""),
            "request_category":     state["payload"].get("ticket", {}).get("category", ""),
            "request_sub_category": state["payload"].get("ticket", {}).get("subcategory", ""),
            "requested_for":        state["payload"].get("ticket", {}).get("requested_for", {}).get("name", ""),
            "opened_by":            state["payload"].get("ticket", {}).get("requested_for", {}).get("name", ""),
        }
        state["attachments"] =      state["payload"].get("attachments", []) or []
        state["service_now"] = {
            "incident_id":          state["payload"].get("ticket", {}).get("sys_id", ""),
            "short_description":    state["payload"].get("ticket", {}).get("short_description", ""),
            "description":          state["payload"].get("ticket", {}).get("description", ""),
            "priority":             state["payload"].get("ticket", {}).get("priority", ""),
            "state":                state["payload"].get("ticket", {}).get("state", ""),
            "assignment_group":     state["payload"].get("ticket", {}).get("assignment_group", ""),
            "opened_by":            state["payload"].get("ticket", {}).get("opened_by", {}).get("name", ""),
            "caller":               state["payload"].get("ticket", {}).get("caller", {}).get("name", ""),
            "category":             state["payload"].get("ticket", {}).get("category", ""),
            "subcategory":          state["payload"].get("ticket", {}).get("subcategory", ""),
            "cmdb_ci":              state["payload"].get("configuration_item", {}).get("hostname", ""),
        }
        state["service_now_updates"] = {
            "work_notes":           [],
            "comments":             [],
            "attachments":          [],
        }


        # --------------
        # Need this db_type and error_category for next node
        # --------------
        state["db_type"] =          state["payload"].get("configuration_item", {}).get("db_type", "")
        state["error_category"] =   None
        # --------------
        # Need this db_type and error_category for next node
        # --------------


        state["environment"] = {
            "hostname":             state["payload"].get("configuration_item", {}).get("hostname", ""),
            "ip_address":           None,
            "os_type":              "Windows",
            "oracle_sid":           None,
            "sql_instance":         state["payload"].get("configuration_item", {}).get("instance", ""),
        },
        state["inputs"] = {
            "alert_message":        state["payload"].get("error_details", {}).get("error_message", ""),
            "rubrik_payload": {
                "error_code":       state["payload"].get("error_details", {}).get("error_code", ""),
                "failure_reason":   state["payload"].get("ticket", {}).get("description", ""),
                "writer_error":     state["payload"].get("error_details", {}).get("error_message", ""),
                "database_name":    state["payload"].get("configuration_item", {}).get("db_type", ""),
            },
            "diagnostic_data": {
                "pre_checks":       {},
                "post_checks":      {},
            },
        }
        state["execution_plan"] = {
            "sop_id":               None,
            "steps":                [],
            "auto_fix_supported":   False,
        }
        state["remediation"] = {
            "actions_performed":    [],
            "status":               "Not_Applicable",
        }
        state["notification"] = {
            "backup_team_notified": False,
            "message_id":           None,
        }
        state["audit"] = {
            "events":               [{"event": "Ticket ingested from ServiceNow", "timestamp": state["payload"].get("timestamp", "")}],
            "operator":             "AI_Agent",
            "timestamp":            state["payload"].get("timestamp", ""),
        }
        state["error"] = {
            "code":                 state["payload"].get("error_details", {}).get("error_code", ""),
            "message":              state["payload"].get("error_details", {}).get("error_message", ""),
            "context": {
                "component":        "VSS" if (state["payload"].get("error_details", {}).get("error_message", "") and "VSS" in str(state["payload"].get("error_details", {}).get("error_message", ""))) else "Unknown",
                "stage":            state["payload"].get("error_details", {}).get("failure_stage", ""),
                "source":           state["payload"].get("source", ""),
            },
        }
        return state