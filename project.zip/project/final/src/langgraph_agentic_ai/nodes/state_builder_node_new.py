# src/langgraph_agentic_ai/nodes/state_builder_node.py
from __future__ import annotations

import logging
import re
from typing import Any, Dict, MutableMapping

from ..state.state import AgentState  # assuming AgentState is a dict-like state
from ..logging.decorators import traced
from ..logging.exceptions import ValidationError  # <- correct import

logger = logging.getLogger(__name__)

# Adjust as needed if your payload can contain sensitive fields
SENSITIVE_KEYS = {"description", "short_description"}

def _safe_payload_summary(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Produce a safe, short summary for logs (INFO), without leaking full text/PII.
    """
    keys = list(payload.keys())[:30]
    preview = {}
    for k in keys:
        v = payload.get(k, None)
        if k in SENSITIVE_KEYS:
            preview[k] = "***REDACTED***"
        else:
            # Keep previews short and stringified
            preview[k] = str(v)[:120] if v is not None else None
    return {"payload_keys": keys, "payload_preview": preview}


class StateBuilderNode:
    @traced("state_builder.build_state_from_payload")
    def build_state_from_payload(self, state: AgentState) -> AgentState:
        """
        Build a normalized AgentState from the incoming ServiceNow payload.

        Raises:
            ValidationError: if `state` or `state['payload']` are missing or malformed.
            GraphExecutionError: for any unexpected exception (via @traced wrapper).
        """
        # ---- Validate inputs early
        if not isinstance(state, MutableMapping):
            raise ValidationError("`state` must be a mutable mapping/dict-like object")

        if "payload" not in state:
            raise ValidationError("`state['payload']` is required")

        payload = state["payload"]
        if not isinstance(payload, MutableMapping):
            raise ValidationError("`state['payload']` must be a JSON object (dict)")

        # ---- Safe log of what's being processed
        logger.info("building_state_from_payload", extra=_safe_payload_summary(payload))

        # Optional example: extract hostname from description (keep off by default)
        # pattern = r" Host\s*:\s*(\S+)"
        # host_match = re.search(pattern, payload.get("description", "") or "")
        # hostname = host_match.group(1) if host_match else None

        # Persist original payload (if you explicitly want it kept)
        # You already have it in state["payload"] so the next line is unnecessary
        # state["payload"] = payload

        # Ticket identity
