from __future__ import annotations
from ..prompt.error_categorizer_prompt import ErrorCategorizerPrompt
from ..state.state import AgentState
from ..LLMs.pepgenx_llm import get_pepgenx_llm_client  
import json

class ErrorCategorizerNode:

    def __init__(self):
        self.llm = get_pepgenx_llm_client()

    def categorize_error(self, state: AgentState):
        print("---- [ErrorCategorizerNode]: Categorizing Error ----")

        prompt = ErrorCategorizerPrompt.generate_prompt(state)

        response = self.llm.generate(prompt = prompt)
        print("---- [ErrorCategorizerNode]: ", response, "----")
        return {"error_category": response["error_category"], "db_type": response["db_type"]}